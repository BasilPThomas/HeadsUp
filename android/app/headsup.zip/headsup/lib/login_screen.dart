import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:headsup/signup_screen.dart';
import 'package:headsup/utilities/constants.dart';
import 'package:headsup/forgotPassword.dart';
import 'package:headsup/screens/nav_bar.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();


  String password = "";
  String email = "";
  final  _key =GlobalKey<FormState>();
  bool _isLoading = false;

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Widget _loginForm() {
    return Form(
        key: _key,
        child: Column(
          children: [
            SizedBox(height: 10.0),
            TextFormField(
              keyboardType: TextInputType.emailAddress,
              // validator: validateEmail,
              controller: emailController,
              validator: (val){
                return RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$').hasMatch(val!)?
                null:"Email Id is not valid";
              },
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.email,
                  color: Colors.white,
                ),
                hintText: 'Enter your Email',
                hintStyle: kHintTextStyle,
              ),
            ),
            SizedBox(height: 10,),
            TextFormField(
              // validator:validatePassword,
              controller: passwordController,
              validator: (val){
                return val!.length>4?null:"Password should be greater than 6 characters";
              },
              obscureText: true,
              keyboardType: TextInputType.visiblePassword,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.lock,
                  color: Colors.white,
                ),
                hintText: 'Enter your password',
                hintStyle: kHintTextStyle,
              ),
            ),
            _buildForgotPasswordBtn(),
            _buildLoginBtn()

          ],
        )
    );
  }

  Widget _buildForgotPasswordBtn() {
    return Container(
      alignment: Alignment.centerRight,
      child: FlatButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ForgotPassword()),);
        },
        padding: EdgeInsets.only(right: 0.0),
        child: Text(
          'Forgot Password?',
          style: kLabelStyle,
        ),
      ),
    );
  }

  Widget _buildLoginBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: () {
          if (_key.currentState!.validate()) {
            _key.currentState!.save();
            print( email);
            print( password);
            setState(() {
              _isLoading = true;
            });
            Signinuser();
            // Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //         builder: (context) => Home()));
          }
        },
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'LOGIN',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  Widget _buildSignupBtn() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SignupScreen()),);
      },
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: 'Don\'t have an Account? ',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.w400,
              ),
            ),
            TextSpan(
              text: 'Sign Up',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/5.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                height: double.infinity,
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 40.0,
                    vertical: 120.0,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Sign In',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 30.0),
                      _loginForm(),
                      _buildSignupBtn(),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

Future Signinuser() async {
  try {
    UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
    );
  } on FirebaseAuthException catch (e) {
    if (e.code == 'user-not-found') {
      print('No user found for that email.');
    } else if (e.code == 'wrong-password') {
      print('Wrong password provided for that user.');
    }
  }
}

  // void signIn()async{
  //   String password = passwordController.text;
  //   String email = nameController.text.trim();
  //
  //   if(email.isNotEmpty && password.isNotEmpty){
  //     try{
  //       await _auth.signInWithEmailAndPassword(email: email, password: password
  //       ).then((user){
  //         return showDialog(
  //             context: context,
  //             builder: (ctx) {
  //               return AlertDialog(
  //                 shape: RoundedRectangleBorder(
  //                     borderRadius: BorderRadius.circular(16)
  //                 ),
  //                 title: Text("Done"),
  //                 content: Text("Login Sucess"),
  //                 actions: [
  //                   FlatButton(
  //                     child: Text("ok"),
  //                     onPressed: () {
  //                       Navigator.of(ctx).pop();
  //                     },
  //                   ),
  //                 ],
  //               );
  //             });
  //       });
  //     }catch(e){
  //       print(e.toString());
  //       return showDialog(
  //           context: context,
  //           builder: (ctx) {
  //             return AlertDialog(
  //               shape: RoundedRectangleBorder(
  //                   borderRadius: BorderRadius.circular(16)
  //               ),
  //               title: Text("error"),
  //               content: Text("${e}"),
  //               actions: [
  //                 FlatButton(
  //                   child: Text("cancel"),
  //                   onPressed: () {
  //                     Navigator.of(ctx).pop();
  //                   },
  //                 ),
  //               ],
  //             );
  //           });
  //     }
  //   }
  //
  // }
  //
  // void _validateLoginInput() async {
  //     if (_key.currentState!.validate()) {
  //       _key.currentState!.save();
  //       print( email);
  //       print( password);
  //       setState(() {
  //         _isLoading = true;
  //       });
  //         _auth.signInWithEmailAndPassword(
  //             email: email, password: password
  //       ).then((user) {
  //           showDialog(
  //               context: context,
  //               builder: (ctx) {
  //                 return AlertDialog(
  //                   shape: RoundedRectangleBorder(
  //                       borderRadius: BorderRadius.circular(16)
  //                   ),
  //                   title: Text("Done"),
  //                   content: Text("Login Sucess"),
  //                   actions: [
  //                     FlatButton(
  //                       child: Text("ok"),
  //                       onPressed: () {
  //                         Navigator.of(ctx).pop();
  //                       },
  //                     ),
  //                   ],
  //                 );
  //               });
  //           print('login');
  //         }).catchError((e) {
  //           print(e);
  //           setState(() {
  //             _isLoading = false;
  //             showDialog(
  //                 context: context,
  //                 builder: (ctx) {
  //                   return AlertDialog(
  //                     shape: RoundedRectangleBorder(
  //                         borderRadius: BorderRadius.circular(16)
  //                     ),
  //                     title: Text("error"),
  //                     content: Text("${e.messsage}"),
  //                     actions: [
  //                       FlatButton(
  //                         child: Text("cancel"),
  //                         onPressed: () {
  //                           Navigator.of(ctx).pop();
  //                         },
  //                       ),
  //                     ],
  //                   );
  //                 });
  //           });
  //         });
  //     }
  //   }
}
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:headsup/screens/nav_bar.dart';
import 'package:headsup/utilities/constants.dart';
import 'package:headsup/forgotPassword.dart';
import 'package:google_sign_in/google_sign_in.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  String name = "";
  String password = "";
  String email = "";
  bool _isLoading = false;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  // final FirebaseFirestore _db = FirebaseFirestore.instance;

  final  _key =GlobalKey<FormState>();

  Widget _buildSignUpBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: () {
          validateInputs();
        },
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'SIGNUP',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }
  GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [
      'email',
      'https://www.googleapis.com/auth/contacts.readonly',
    ],
  );


  Widget _signupForm() {
      return Form(
          key: _key,
          child: Column(
            children: [
              TextFormField(
                controller: nameController,
                // validator: (val){
                //   return val!.isNotEmpty || val.length < 4 ? val="Username is not valid":val =null;
                // },
                keyboardType: TextInputType.emailAddress,
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                ),
                decoration: InputDecoration(
                  filled: true,
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.accessibility,
                    color: Colors.white,
                  ),
                  hintText: 'Enter your Name',
                  hintStyle: kHintTextStyle,
                ),
              ),
              SizedBox(height: 10.0),
              TextFormField(
                controller:emailController ,
                keyboardType: TextInputType.emailAddress,
                validator: (val){
                  return RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$').hasMatch(val!)? null:"Email Id is not valid";
                },
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.email,
                    color: Colors.white,
                  ),
                  hintText: 'Enter your Email',
                  hintStyle: kHintTextStyle,
                ),
              ),
              SizedBox(height: 10,),
              TextFormField(
                controller: passwordController,
                validator: (val){
                  return val!.length>6?null:"Password should be greater than 6 characters";
                },
                obscureText: true,
                keyboardType: TextInputType.visiblePassword,
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.lock,
                    color: Colors.white,
                  ),
                  hintText: 'Enter your password',
                  hintStyle: kHintTextStyle,
                ),
              ),
              SizedBox(height: 30,),
              _buildSignUpBtn()
            ],
          )
      );
  }

  Widget _buildSignInWithText() {
    return Column(
      children: <Widget>[
        Text(
          '- OR -',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w400,
          ),
        ),
        SizedBox(height: 20.0),
        FlatButton.icon(
          onPressed: () {
            // _signupUsingGoogle();
          },
          icon: Icon(
            FontAwesomeIcons.googleDrive, color: Colors.red, size: 30,),
          label: Text("Sign-in using Gmail"),
        ),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/5.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                height: double.infinity,
                child: SingleChildScrollView(
                  // physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 40.0,
                    vertical: 120.0,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Sign UP',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 30.0),
                      _signupForm(),
                      SizedBox(
                        height: 30.0,
                      ),
                      _buildSignInWithText(),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void validateInputs() {
    if (_key.currentState!.validate()) {
      _key.currentState!.save();
      print(name);
      print( email);
      print( password);
      setState(() {
        _isLoading = true;
      });

      _auth.createUserWithEmailAndPassword(
          email: email, password: password
      ).then((user){
        print("sucess");
      }).catchError((e) {
        print(e);
        setState(() {
          _isLoading = false;
          showDialog(
              context: context,
              builder: (ctx) {
                return AlertDialog(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)
                  ),
                  title: Text("error"),
                  content: Text("${e.messsage}"),
                  actions: [
                    FlatButton(
                      child: Text("cancel"),
                      onPressed: () {
                        Navigator.of(ctx).pop();
                      },
                    ),
                  ],
                );
              });
        });
      });
    }
  }


    void _signupUsingGoogle() async {
    try{
      final GoogleSignInAccount googleuser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.getcredential(
        accessToken: googleAuth.accessToken,
        idToken:googleAuth.idToken,
      );
      final FirebaseUser user =(await _auth.signInWithCredential(credential)).user;
      print("signed "+user.displayName);
    } catch(e) {
      showDialog(
          context: context,
          builder: (ctx){
            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)
              ),
              title: Text("error"),
                        content: Text('${e.message}'),
                        actions: [
                          FlatButton(
                            child: Text("cancel"),
                            onPressed: (){
                              Navigator.of(ctx).pop();
                            },
                          ),
              ],
            );
          });
  }
}
}